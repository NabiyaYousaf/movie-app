import React from 'react'
import {Routes,Route} from "react-router-dom";
import ErrorPage from './ErrorPage';
import Home from './Home';
import SIngleMovie from './SIngleMovie';
const App = () => {
  return (
    <>
      <Routes>
        <Route path="/" element={<Home/>} />
        <Route path="movie/:id" element={<SIngleMovie/>} />
        <Route path="*" element={<ErrorPage/>} />
      </Routes>
    </>
  )
}

export default App