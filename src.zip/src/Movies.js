import React from 'react'
import { NavLink } from 'react-router-dom';
import { useGlobalContext } from './context'

const Movies = () => {
  const {movie,isLoading}=useGlobalContext();
  if(isLoading){
    return(
    <h1 className='loading'>Loading...</h1>
    )
  }
  return (
    <section>
        <div className='container grid-col-4'>
        
            {
            movie.map((curMovie)=>{
              const {Title,Poster,imdbID}=curMovie;
              return(
                <NavLink to={`movie/${imdbID}`} key={imdbID} className="mainMovie">
                  <div className='card'>
                  <h3 className='title'>{Title}</h3>
                  <img src={Poster} alt={imdbID} />
                    
                  </div>
                </NavLink>
               
              )
            })
          }
        </div>
    </section>
   
  )
}

export default Movies