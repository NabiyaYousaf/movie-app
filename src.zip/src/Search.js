import React from 'react'
import { useGlobalContext } from './context'

const Search = () => {
  const {query,setQuery,isError}=useGlobalContext();
  return (
    <section>
      <div className='mainSearch'>
        <h3 className='search-heading'>Search Your Favourite Movie</h3>
        <form action="#" onSubmit={(e)=>{e.preventDefault()}}>
          <input type="text" placeholder='Search here...'
          value={query}
          onChange={(e)=>setQuery(e.target.value)}
           />
        </form>
      </div>
      <div>
     
        <h4 style={{textAlign:"center",color:"orange",letterSpacing:"0.5px"}}>
          
          {isError.show && isError.msg}
        </h4>
      </div>

    </section>
  )
}

export default Search