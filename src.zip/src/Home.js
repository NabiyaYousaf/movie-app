import React from 'react'
import Movies from './Movies'
import Search from './Search'
const Home = () => {
  return (
    <>
      <Search/>
      <Movies/>
    </>
  )
}

export default Home