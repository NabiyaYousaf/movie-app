import React,{useState,useEffect} from 'react'
import {NavLink, useParams} from 'react-router-dom';
import {API_URL} from "./context";
const SIngleMovie = () => {
    const {id}=useParams();
    const [isLoading,setIsLoading]=useState(true);
    const [movie,setMovie]=useState("");
    const get_Movie=async (url)=>{
        try{
            const res=await fetch(url);
            const data=await res.json();
            console.log(data);
            if(data.Response === "True"){
                setIsLoading(false);
                setMovie(data);
            }else{
                // setIsError(
                // {show:true,
                // msg:data.Error}
                // )
            }
        }catch(error){
            console.log(error);

        }
    }
    useEffect(()=>{

       let timerOut= setTimeout(() => {
            get_Movie(`${API_URL}&i=${id}`);
        }, 800);
        return ()=>clearTimeout(timerOut);
    },[]);
    if(isLoading){
      return(
      <h1 className='loading'>Loading...</h1>
      )
    }
  return (
    <section className='single_movie_body'>
    {/* left side of div */}
      <div className='main-card'>
        <figure>
          <img src={movie.Poster} alt="Movie_Poster" />
        </figure>
         {/* right side of div */}
        <div className='right-card'>
          <h3>Title: </h3><span>{movie.Title}</span>
          <h3>Actors: </h3><span>{movie.Actors}</span>
          <h3>Country: </h3><span>{movie.Country}</span>
          {/* <h3>Language: </h3><span style={{paddingBottom:"10px"}}>{movie.Language}</span><br/> */}<br></br><br></br>
           {/* back button for back to home page */}
            <NavLink to="/" className="backButton">
              Go Back
            </NavLink>
        </div>
       
      </div>
       
    </section>
  )
}

export default SIngleMovie